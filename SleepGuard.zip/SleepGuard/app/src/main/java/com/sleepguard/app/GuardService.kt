package com.sleepguard.app

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot

class GuardService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GuardService? = null
        const val PREFS = "sleepguard"
        const val KEY_ON = "on"
        const val KEY_MIN = "minutes"
        const val CATCH_SECONDS = 40
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var ball: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var vx = 0f
    private var vy = 0f
    private var dragging = false
    private var receiverRegistered = false

    private val prefs get() = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val showBallTask = Runnable { showBall() }
    private val lockTask = Runnable { lockNow() }
    private val moveTask = object : Runnable {
        override fun run() {
            moveBall()
            if (ball != null) handler.postDelayed(this, 16)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                // Screen band: sab timer/ball hata do (ON rehta hai)
                Intent.ACTION_SCREEN_OFF -> clearAll()
                // Phone unlock hua: agar ON hai to timer dobara shuru
                Intent.ACTION_USER_PRESENT ->
                    if (prefs.getBoolean(KEY_ON, false)) scheduleBall()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(screenReceiver, filter)
            }
            receiverRegistered = true
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        clearAll()
        if (receiverRegistered) {
            try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        instance = null
        return super.onUnbind(intent)
    }

    // ---- Main app yahan se control karta hai ----

    fun startGuard() {
        prefs.edit().putBoolean(KEY_ON, true).apply()
        scheduleBall()
    }

    fun stopGuard() {
        prefs.edit().putBoolean(KEY_ON, false).apply()
        clearAll()
    }

    // ---- Andar ka kaam ----

    private fun scheduleBall() {
        clearAll()
        val minutes = prefs.getInt(KEY_MIN, 10)
        handler.postDelayed(showBallTask, minutes * 60_000L)
    }

    private fun clearAll() {
        handler.removeCallbacks(showBallTask)
        handler.removeCallbacks(lockTask)
        removeBall()
    }

    private fun removeBall() {
        handler.removeCallbacks(moveTask)
        ball?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        ball = null
        params = null
        dragging = false
    }

    private fun lockNow() {
        removeBall()
        // Lock ke baad guard OFF; dobara chalane ke liye app mein ON karo
        prefs.edit().putBoolean(KEY_ON, false).apply()
        performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    }

    private fun ballCaught() {
        handler.removeCallbacks(lockTask)
        removeBall()
        if (prefs.getBoolean(KEY_ON, false)) scheduleBall() // timer restart
    }

    private fun showBall() {
        removeBall()
        val dm = resources.displayMetrics
        val d = dm.density
        val size = (84 * d).toInt()

        val view = TextView(this).apply {
            text = "\uD83D\uDC4B"
            textSize = 30f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#FF6D00"))
                setStroke((3 * d).toInt(), Color.WHITE)
            }
        }

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ((dm.widthPixels - size) * Math.random()).toInt()
            y = ((dm.heightPixels - size) * Math.random()).toInt()
        }

        var downX = 0f
        var downY = 0f
        val dragNeeded = 100 * d // itna door khinchna padega tabhi ball hategi

        view.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = true
                    downX = ev.rawX
                    downY = ev.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (ev.rawX - size / 2).toInt()
                    lp.y = (ev.rawY - size / 2).toInt()
                    try { wm.updateViewLayout(view, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (hypot(ev.rawX - downX, ev.rawY - downY) >= dragNeeded) {
                        ballCaught()
                    } else {
                        dragging = false // sirf chhua, hataya nahi: ball phir ghoomegi
                    }
                    true
                }
                else -> false
            }
        }

        wm.addView(view, lp)
        ball = view
        params = lp
        val speed = 3f * d
        vx = speed
        vy = speed * 0.8f
        handler.post(moveTask)
        handler.postDelayed(lockTask, CATCH_SECONDS * 1000L)
    }

    private fun moveBall() {
        val v = ball ?: return
        val lp = params ?: return
        if (dragging) return
        val dm = resources.displayMetrics
        lp.x += vx.toInt()
        lp.y += vy.toInt()
        val maxX = dm.widthPixels - lp.width
        val maxY = dm.heightPixels - lp.height
        if (lp.x < 0) { lp.x = 0; vx = abs(vx) }
        if (lp.x > maxX) { lp.x = maxX; vx = -abs(vx) }
        if (lp.y < 0) { lp.y = 0; vy = abs(vy) }
        if (lp.y > maxY) { lp.y = maxY; vy = -abs(vy) }
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }
}

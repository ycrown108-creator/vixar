package com.sleepguard.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val options = intArrayOf(1, 5, 10, 15, 20, 25, 30)
    private lateinit var toggle: Switch
    private lateinit var status: TextView
    private lateinit var group: RadioGroup
    private lateinit var permBtn: Button
    private var updating = false

    private val prefs get() = getSharedPreferences(GuardService.PREFS, MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(56), dp(24), dp(24))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply {
            text = "Sleep Guard"
            textSize = 28f
            setTextColor(Color.BLACK)
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(8), 0, dp(16))
        }
        root.addView(status)

        permBtn = Button(this).apply {
            text = "Accessibility permission kholo"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(permBtn)

        toggle = Switch(this).apply {
            text = "ON / OFF   "
            textSize = 22f
            setPadding(0, dp(16), 0, dp(16))
        }
        root.addView(toggle)

        root.addView(TextView(this).apply {
            text = "Timer:"
            textSize = 16f
            setPadding(0, dp(16), 0, dp(8))
        })

        group = RadioGroup(this)
        options.forEachIndexed { i, m ->
            group.addView(RadioButton(this).apply {
                id = 1000 + i
                text = "$m min"
                textSize = 18f
            })
        }
        root.addView(group)

        toggle.setOnCheckedChangeListener { _, on -> if (!updating) onToggle(on) }
        group.setOnCheckedChangeListener { _, id -> if (!updating) onTimerPicked(id - 1000) }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun onToggle(on: Boolean) {
        val service = GuardService.instance
        if (on) {
            if (service == null) {
                Toast.makeText(
                    this,
                    "Pehle Accessibility mein 'Sleep Guard' ON karo",
                    Toast.LENGTH_LONG
                ).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                service.startGuard()
            }
        } else {
            if (service != null) service.stopGuard()
            else prefs.edit().putBoolean(GuardService.KEY_ON, false).apply()
        }
        refresh()
    }

    private fun onTimerPicked(index: Int) {
        if (index !in options.indices) return
        prefs.edit().putInt(GuardService.KEY_MIN, options[index]).apply()
        // Agar ON hai to naye timer se dobara shuru
        if (prefs.getBoolean(GuardService.KEY_ON, false)) {
            GuardService.instance?.startGuard()
        }
        refresh()
    }

    private fun refresh() {
        updating = true
        val hasPerm = GuardService.instance != null
        val on = hasPerm && prefs.getBoolean(GuardService.KEY_ON, false)
        val min = prefs.getInt(GuardService.KEY_MIN, 10)

        toggle.isChecked = on
        group.check(1000 + options.indexOf(min).coerceAtLeast(0))
        permBtn.visibility = if (hasPerm) View.GONE else View.VISIBLE
        status.text = when {
            !hasPerm -> "Permission band hai. Neeche wale button se Accessibility mein 'Sleep Guard' ON karo, phir wapas aao."
            on -> "ON: $min min baad ball aayegi. 40 sec mein na hati to screen lock."
            else -> "OFF: app kuch nahi kar raha."
        }
        updating = false
    }
}

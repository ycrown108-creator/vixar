package com.jarvis.app;

import android.Manifest;
import android.app.Activity;
import android.app.Presentation;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/* JARVIS: phone shows the camera page when a TV (wireless display) is connected,
   the TV gets the real 16:9 UI through a Presentation. No TV -> the UI runs on the phone. */
public class MainActivity extends Activity {
    static final String BASE = "http://127.0.0.1:8080/";
    private WebView phone;
    private TvPresentation pres;
    private DisplayManager dm;
    private final Handler h = new Handler(Looper.getMainLooper());

    private class Bridge {
        @JavascriptInterface
        public String openApp(String pkg) {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) return "no";
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return "ok";
            } catch (Exception e) {
                return "no";
            }
        }
    }

    private void load(WebView w, String url) {
        w.setTag(url);
        w.loadUrl(url);
    }

    private WebView make(Context c, String url) {
        final WebView w = new WebView(c);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        w.setBackgroundColor(0xFF05070D);
        w.addJavascriptInterface(new Bridge(), "Android");
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            request.grant(request.getResources());
                        } catch (Exception e) {
                            /* ignore */
                        }
                    }
                });
            }
        });
        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(final WebView view, WebResourceRequest req, WebResourceError err) {
                if (!req.isForMainFrame()) return;
                final Object t = view.getTag();
                view.loadData("<body style='background:#05070d;color:#ffe9b8;font-family:sans-serif;text-align:center;padding-top:15vh'>"
                        + "<h1>JARVIS server band hai</h1><h2>Termux me ye chalao:</h2>"
                        + "<h2 style='color:#f5c04a'>bash ~/jarvis/start.sh</h2><p>Apne aap dobara try ho raha hai...</p></body>",
                        "text/html", "utf-8");
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (t instanceof String) view.loadUrl((String) t);
                    }
                }, 3000);
            }
        });
        w.setTag(url);
        w.loadUrl(url);
        return w;
    }

    private class TvPresentation extends Presentation {
        TvPresentation(Context c, Display d) {
            super(c, d);
        }

        @Override
        protected void onCreate(Bundle b) {
            super.onCreate(b);
            WebView tv = make(getContext(), BASE + "index.html?tv=1");
            setContentView(tv);
        }
    }

    private Display findTv() {
        Display[] ds = dm.getDisplays();
        for (int i = 0; i < ds.length; i++) {
            Display d = ds[i];
            if (d.getDisplayId() != Display.DEFAULT_DISPLAY && (d.getFlags() & Display.FLAG_PRESENTATION) != 0) return d;
        }
        return null;
    }

    private void sync() {
        Display d = findTv();
        if (d != null && pres == null) {
            try {
                pres = new TvPresentation(this, d);
                pres.show();
                load(phone, BASE + "phone.html?auto=1");
            } catch (Exception e) {
                pres = null;
            }
        } else if (d == null && pres != null) {
            try {
                pres.dismiss();
            } catch (Exception e) {
                /* ignore */
            }
            pres = null;
            load(phone, BASE + "index.html");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        phone = make(this, BASE + "index.html");
        setContentView(phone);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
        }
        dm = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        dm.registerDisplayListener(new DisplayManager.DisplayListener() {
            @Override
            public void onDisplayAdded(int id) {
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        sync();
                    }
                });
            }

            @Override
            public void onDisplayRemoved(int id) {
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        sync();
                    }
                });
            }

            @Override
            public void onDisplayChanged(int id) {
            }
        }, h);
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                sync();
            }
        }, 1500);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        Object t = phone.getTag();
        if (t instanceof String) phone.loadUrl((String) t);
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    protected void onDestroy() {
        try {
            if (pres != null) pres.dismiss();
        } catch (Exception e) {
            /* ignore */
        }
        super.onDestroy();
    }
}
